-- 环世界专页只在此文件定义画面；手机仅提供通用 Canvas 和动作命中接口。
local palette = {
    background = '#0B0D10', panel = '#121519', line = '#2A2E36',
    text = '#E8EAED', secondary = '#A9B1BC', muted = '#7D8693',
    amber = '#F0B24A', amberText = '#F5D9A6', amberBg = '#2A2216',
    danger = '#F2706B'
}

local function tone(value)
    if value == 'danger' then return palette.danger end
    if value == 'warning' then return palette.amberText end
    return palette.text
end

local function panel(ctx, x, y, width, height, selected)
    local edge = palette.line
    local fill = palette.panel
    if selected then edge = palette.amber fill = palette.amberBg end
    ctx.rect(x, y, width, height, edge)
    ctx.rect(x + 1, y + 1, width - 2, height - 2, fill)
end

local function cards(ctx, items, x, y, width, height, columns, gap)
    local rows = math.ceil(#items / columns)
    local cardWidth = (width - (columns - 1) * gap) / columns
    local cardHeight = (height - (rows - 1) * gap) / rows
    for i = 1, #items do
        local item = items[i]
        local column = (i - 1) % columns
        local row = math.floor((i - 1) / columns)
        local left = x + column * (cardWidth + gap)
        local top = y + row * (cardHeight + gap)
        local compact = cardHeight < 82
        panel(ctx, left, top, cardWidth, cardHeight, false)
        ctx.text(item.label, left + 10, top + 18, 12, palette.secondary, cardWidth - 20)
        local valueSize = 27
        local valueY = top + 49
        if compact then valueSize = 23 valueY = top + 43 end
        ctx.text(item.value, left + 10, valueY, valueSize, tone(item.tone), cardWidth - 20)
        ctx.text(item.detail, left + 10, top + cardHeight - 10, 10, palette.muted, cardWidth - 20)
    end
end

local function people(ctx, items, x, y, width, height, gap)
    if #items == 0 then return end
    local rowHeight = (height - (#items - 1) * gap) / #items
    for i = 1, #items do
        local item = items[i]
        local top = y + (i - 1) * (rowHeight + gap)
        local enabled = ctx.enabled(item.action)
        local ink = tone(item.tone)
        if not enabled then ink = palette.muted end
        panel(ctx, x, top, width, rowHeight, false)
        ctx.text(item.title, x + 10, top + 18, 14, ink, width - 90)
        ctx.text(item.value, x + width - 75, top + 18, 14, ink, 65)
        ctx.text(item.detail, x + 10, top + rowHeight - 8, 10, palette.muted, width - 20)
        if enabled then ctx.hit(item.action, x, top, width, rowHeight) end
    end
end

function render(ctx, data)
    local width = ctx.width
    local height = ctx.height
    local margin = math.max(12, math.min(24, width * 0.035))
    local gap = 8
    local contentTop = margin + 70
    ctx.rect(0, 0, width, height, palette.background)
    ctx.text(data.title, margin, margin + 22, 24, palette.text, width - margin * 2 - 132)
    ctx.text(data.status, width - margin - 126, margin + 20, 14, palette.secondary, 126)
    ctx.text(data.subtitle, margin, margin + 44, 12, palette.muted, width - margin * 2)
    ctx.line(margin, margin + 58, width - margin, margin + 58, palette.line, 1)

    local controls = data.controls
    local buttonHeight = 48
    local buttonTop = height - margin - buttonHeight
    local contentBottom = height - margin
    if #controls > 0 then contentBottom = buttonTop - 32 end
    if #data.cards > 0 then
        local contentHeight = math.max(100, contentBottom - contentTop)
        local contentWidth = width - margin * 2
        if width > height * 1.25 then
            local cardWidth = (contentWidth - gap) * 0.59
            cards(ctx, data.cards, margin, contentTop, cardWidth, contentHeight, 3, gap)
            people(ctx, data.rows, margin + cardWidth + gap, contentTop, contentWidth - cardWidth - gap, contentHeight, gap)
        else
            local rowHeight = 42
            local peopleHeight = #data.rows * rowHeight + math.max(0, #data.rows - 1) * gap
            local cardHeight = contentHeight - peopleHeight
            if #data.rows > 0 then cardHeight = cardHeight - 12 end
            cards(ctx, data.cards, margin, contentTop, contentWidth, math.max(120, cardHeight), 2, gap)
            people(ctx, data.rows, margin, contentTop + cardHeight + 12, contentWidth, peopleHeight, gap)
        end
    else
        ctx.text(data.notice, margin, contentTop + 34, 18, palette.secondary, width - margin * 2)
    end

    if #controls > 0 then
        local message = data.notice
        if ctx.feedback ~= '' then message = ctx.feedback end
        ctx.text(message, margin, buttonTop - 12, 12, palette.secondary, width - margin * 2)
        local buttonWidth = (width - margin * 2 - (#controls - 1) * gap) / #controls
        for i = 1, #controls do
            local control = controls[i]
            local left = margin + (i - 1) * (buttonWidth + gap)
            local enabled = ctx.enabled(control.id)
            local selected = ctx.selected(control.id)
            local ink = palette.text
            if selected then ink = palette.amberText end
            if not enabled then ink = palette.muted end
            panel(ctx, left, buttonTop, buttonWidth, buttonHeight, selected)
            ctx.text(control.label, left + 12, buttonTop + 30, 16, ink, buttonWidth - 24)
            if enabled then ctx.hit(control.id, left, buttonTop, buttonWidth, buttonHeight) end
        end
    end
end
